/**
 * Copyright (C), 2015-2018, XXX有限公司
 * FileName: Test1204
 * Author:   郭新晔
 * Date:     2018/12/4 0004 21:44
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
package test.test;

import java.util.List;

/**
 * 〈〉
 *
 * @create 2018/12/4 0004
 */
public class Test1204 {
    public static void main(String[] args) {
        List<String> strs = null;
        for (String item : strs) {
            System.out.println(item);
        }
    }
}